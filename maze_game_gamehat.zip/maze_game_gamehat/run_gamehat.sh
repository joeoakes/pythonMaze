#!/usr/bin/env bash
set -e

# Helpful defaults for many Pi handhelds.
# If this causes issues on your setup, just run: python3 main.py

export SDL_AUDIODRIVER=${SDL_AUDIODRIVER:-alsa}
export SDL_VIDEODRIVER=${SDL_VIDEODRIVER:-fbcon}
export SDL_FBDEV=${SDL_FBDEV:-/dev/fb0}

# Some images need this; harmless otherwise.
export PYTHONUNBUFFERED=1

python3 main.py --fullscreen
