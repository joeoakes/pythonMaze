# Python Maze Game (Raspberry Pi GameHat-ready)

A small, fast **Pygame** maze game that runs great on Raspberry Pi and handhelds like the **GameHat**.

- Procedurally generates mazes (depth-first search / perfect maze)
- Multiple levels (maze size increases)
- Works with **keyboard** out of the box
- Optional **GPIO buttons** support (via `gpiozero`) for GameHat-style D-pad buttons

## 1) Install

### Raspberry Pi OS (recommended)
```bash
sudo apt update
sudo apt install -y python3-pip python3-pygame
```

If `python3-pygame` is unavailable on your image, use:
```bash
pip3 install -r requirements.txt
```

## 2) Run

From the project folder:
```bash
python3 main.py
```

### Fullscreen (nice for handhelds)
```bash
python3 main.py --fullscreen
```

### Small fixed resolution (good for 320x240 / 480x320 screens)
```bash
python3 main.py --width 480 --height 320
```

### GameHat helper script
Try this on Raspberry Pi handhelds (may help framebuffer/SDL setup):
```bash
chmod +x run_gamehat.sh
./run_gamehat.sh
```

## 3) Controls

### Keyboard
- Move: **Arrow keys** or **WASD**
- Restart level: **R**
- Next level (if at goal): **Enter**
- Quit: **Esc**

### GPIO Buttons (optional)
Edit `config.py` and set:
- `USE_GPIO = True`
- Update the pin numbers in `GPIO_PINS` if your GameHat wiring differs.

This uses `gpiozero.Button` with pull-ups (active-low) by default.

## Notes / Troubleshooting

- If you see a black screen on framebuffer devices, try:
  - running `./run_gamehat.sh`
  - or exporting SDL variables manually (see that script).
- If you want analog-stick or /dev/input support, the code is structured so you can add it easily in `input_devices.py`.

Enjoy!
