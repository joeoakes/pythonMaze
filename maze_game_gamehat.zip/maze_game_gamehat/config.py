# Game configuration and optional GPIO support.

# Toggle GPIO button support (requires gpiozero)
USE_GPIO = False

# Active-low buttons with internal pull-up (typical for many handheld hats)
GPIO_ACTIVE_LOW = True

# Map logical directions/actions to BCM GPIO pins.
# IMPORTANT: These vary by GameHat and wiring. If movement doesn't work, change these.
GPIO_PINS = {
    "UP": 5,
    "DOWN": 6,
    "LEFT": 13,
    "RIGHT": 19,
    "A": 26,       # optional action (restart)
    "START": 21,   # optional action (next/confirm)
}

# Game defaults
DEFAULT_WIDTH = 480
DEFAULT_HEIGHT = 320
FPS = 60

# Rendering
BACKGROUND = (18, 18, 22)
WALL = (220, 220, 230)
PLAYER = (90, 220, 130)
GOAL = (240, 180, 70)
HUD = (200, 200, 210)

# Gameplay
START_COLS = 12
START_ROWS = 8
LEVEL_GROWTH = 2    # how many cells to add per level
MOVE_COOLDOWN_MS = 60  # button-repeat/step rate
