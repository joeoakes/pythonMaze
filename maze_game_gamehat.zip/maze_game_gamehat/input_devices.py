from __future__ import annotations
from dataclasses import dataclass
from typing import Dict, Optional
import time

import pygame

try:
    from gpiozero import Button
except Exception:
    Button = None

import config

@dataclass
class Actions:
    up: bool = False
    down: bool = False
    left: bool = False
    right: bool = False
    a: bool = False
    start: bool = False
    restart: bool = False
    confirm: bool = False
    quit: bool = False

class InputManager:
    def __init__(self):
        self._last_step_ms = 0
        self._cooldown = int(getattr(config, "MOVE_COOLDOWN_MS", 60))

        self.gpio_buttons: Dict[str, object] = {}
        if config.USE_GPIO and Button is not None:
            self._init_gpio()

    def _init_gpio(self):
        # gpiozero.Button defaults to pull_up=True which suits active-low wiring.
        pins = config.GPIO_PINS
        pull_up = True  # active-low with pull-up
        if not config.GPIO_ACTIVE_LOW:
            # active-high: you'd typically use pull_down, but gpiozero's Button expects pull_up.
            # We'll keep pull_up=True and invert in read if needed.
            pull_up = True

        def mk(name):
            pin = pins.get(name)
            if pin is None:
                return None
            return Button(pin, pull_up=pull_up, bounce_time=0.01)

        for k in ("UP", "DOWN", "LEFT", "RIGHT", "A", "START"):
            b = mk(k)
            if b is not None:
                self.gpio_buttons[k] = b

    def _gpio_pressed(self, name: str) -> bool:
        b = self.gpio_buttons.get(name)
        if not b:
            return False
        pressed = bool(getattr(b, "is_pressed", False))
        if not config.GPIO_ACTIVE_LOW:
            pressed = not pressed
        return pressed

    def _step_ok(self) -> bool:
        now = int(time.time() * 1000)
        if now - self._last_step_ms >= self._cooldown:
            self._last_step_ms = now
            return True
        return False

    def poll(self) -> Actions:
        a = Actions()

        # Pygame quit events
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                a.quit = True
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    a.quit = True
                elif event.key == pygame.K_r:
                    a.restart = True
                elif event.key in (pygame.K_RETURN, pygame.K_KP_ENTER):
                    a.confirm = True

        keys = pygame.key.get_pressed()

        # Direction keys (allow holding, but rate-limited for grid stepping)
        want_up = keys[pygame.K_UP] or keys[pygame.K_w]
        want_down = keys[pygame.K_DOWN] or keys[pygame.K_s]
        want_left = keys[pygame.K_LEFT] or keys[pygame.K_a]
        want_right = keys[pygame.K_RIGHT] or keys[pygame.K_d]

        # Add GPIO (if enabled)
        want_up = want_up or self._gpio_pressed("UP")
        want_down = want_down or self._gpio_pressed("DOWN")
        want_left = want_left or self._gpio_pressed("LEFT")
        want_right = want_right or self._gpio_pressed("RIGHT")

        # Actions
        a.a = keys[pygame.K_SPACE] or self._gpio_pressed("A")
        a.start = keys[pygame.K_TAB] or self._gpio_pressed("START")

        if a.a:
            a.restart = True
        if a.start:
            a.confirm = True

        # Apply step cooldown so player moves one cell per step
        if self._step_ok():
            a.up = want_up
            a.down = want_down
            a.left = want_left
            a.right = want_right

        return a
