from __future__ import annotations
import argparse
import time
import math

import pygame

import config
from maze import Maze, N, E, S, W
from input_devices import InputManager

def clamp(n, lo, hi):
    return max(lo, min(hi, n))

def draw_text(screen, font, text, x, y, color):
    surf = font.render(text, True, color)
    screen.blit(surf, (x, y))

def compute_cell_size(width, height, cols, rows, margin=30):
    # Fit grid into screen with margins for HUD
    usable_w = max(40, width - 2 * margin)
    usable_h = max(40, height - 2 * margin - 20)
    cell = int(min(usable_w / cols, usable_h / rows))
    cell = max(10, cell)
    return cell

def main():
    parser = argparse.ArgumentParser(description="Maze Game for Raspberry Pi / GameHat")
    parser.add_argument("--width", type=int, default=config.DEFAULT_WIDTH)
    parser.add_argument("--height", type=int, default=config.DEFAULT_HEIGHT)
    parser.add_argument("--fullscreen", action="store_true")
    parser.add_argument("--seed", type=int, default=None)
    args = parser.parse_args()

    pygame.init()
    pygame.display.set_caption("Maze Game")

    flags = 0
    if args.fullscreen:
        flags |= pygame.FULLSCREEN

    screen = pygame.display.set_mode((args.width, args.height), flags)
    clock = pygame.time.Clock()

    font = pygame.font.SysFont(None, 22)
    big = pygame.font.SysFont(None, 28)

    input_mgr = InputManager()

    level = 1
    cols = config.START_COLS
    rows = config.START_ROWS

    def new_level():
        nonlocal maze, px, py, gx, gy, start_time, won
        maze = Maze(cols, rows, seed=args.seed)
        px, py = 0, 0
        gx, gy = cols - 1, rows - 1
        start_time = time.time()
        won = False

    maze = None
    px = py = gx = gy = 0
    start_time = time.time()
    won = False
    new_level()

    running = True
    while running:
        dt = clock.tick(config.FPS) / 1000.0

        actions = input_mgr.poll()
        if actions.quit:
            running = False

        if actions.restart:
            new_level()

        if not won:
            if actions.up:
                px, py = maze.move(px, py, N)
            elif actions.right:
                px, py = maze.move(px, py, E)
            elif actions.down:
                px, py = maze.move(px, py, S)
            elif actions.left:
                px, py = maze.move(px, py, W)

            if (px, py) == (gx, gy):
                won = True

        else:
            if actions.confirm:
                level += 1
                # increase size gradually
                nonlocal_cols = config.LEVEL_GROWTH
                nonlocal_rows = config.LEVEL_GROWTH
                # Keep growth proportional to screen shape
                if args.width >= args.height:
                    cols_inc, rows_inc = nonlocal_cols, max(1, nonlocal_rows - 1)
                else:
                    cols_inc, rows_inc = max(1, nonlocal_cols - 1), nonlocal_rows
                cols_new = cols + cols_inc
                rows_new = rows + rows_inc
                # Cap size so it stays playable on small screens
                cols_cap = max(10, int(args.width / 18))
                rows_cap = max(8, int(args.height / 18))
                cols = clamp(cols_new, 6, cols_cap)
                rows = clamp(rows_new, 6, rows_cap)
                new_level()

        # Render
        w, h = screen.get_size()
        screen.fill(config.BACKGROUND)

        cell = compute_cell_size(w, h, cols, rows, margin=24)
        ox = (w - cols * cell) // 2
        oy = (h - rows * cell) // 2 + 10

        # Draw walls
        for y in range(rows):
            for x in range(cols):
                c = maze.cell(x, y)
                x0 = ox + x * cell
                y0 = oy + y * cell
                x1 = x0 + cell
                y1 = y0 + cell
                if c.walls[0]:
                    pygame.draw.line(screen, config.WALL, (x0, y0), (x1, y0), 2)
                if c.walls[1]:
                    pygame.draw.line(screen, config.WALL, (x1, y0), (x1, y1), 2)
                if c.walls[2]:
                    pygame.draw.line(screen, config.WALL, (x0, y1), (x1, y1), 2)
                if c.walls[3]:
                    pygame.draw.line(screen, config.WALL, (x0, y0), (x0, y1), 2)

        # Goal
        gx0 = ox + gx * cell + cell // 2
        gy0 = oy + gy * cell + cell // 2
        pygame.draw.circle(screen, config.GOAL, (gx0, gy0), max(5, cell // 4))

        # Player
        px0 = ox + px * cell + cell // 2
        py0 = oy + py * cell + cell // 2
        pygame.draw.circle(screen, config.PLAYER, (px0, py0), max(5, cell // 4))

        elapsed = time.time() - start_time
        draw_text(screen, big, f"Level {level}", 10, 8, config.HUD)
        draw_text(screen, font, f"Size: {cols}x{rows}", 10, 30, config.HUD)
        draw_text(screen, font, f"Time: {elapsed:0.1f}s", 10, 48, config.HUD)

        if won:
            msg = "YOU WIN! Press Enter/Start for next level"
            draw_text(screen, big, msg, 10, h - 28, config.HUD)
        else:
            hint = "Move: arrows/WASD • R=restart • Esc=quit"
            draw_text(screen, font, hint, 10, h - 20, config.HUD)

        pygame.display.flip()

    pygame.quit()

if __name__ == "__main__":
    main()
