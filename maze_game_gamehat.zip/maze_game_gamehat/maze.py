from __future__ import annotations
from dataclasses import dataclass
from typing import List, Tuple
import random

# Walls: N, E, S, W (clockwise)
N, E, S, W = 0, 1, 2, 3

DX = {N: 0, E: 1, S: 0, W: -1}
DY = {N: -1, E: 0, S: 1, W: 0}
OPP = {N: S, E: W, S: N, W: E}

@dataclass
class Cell:
    x: int
    y: int
    walls: List[bool]  # [N, E, S, W]
    visited: bool = False

class Maze:
    def __init__(self, cols: int, rows: int, seed: int | None = None):
        self.cols = max(2, int(cols))
        self.rows = max(2, int(rows))
        self.seed = seed
        if seed is not None:
            random.seed(seed)

        self.grid = [[Cell(x, y, [True, True, True, True], False) for x in range(self.cols)]
                     for y in range(self.rows)]
        self._generate()

    def _in_bounds(self, x: int, y: int) -> bool:
        return 0 <= x < self.cols and 0 <= y < self.rows

    def cell(self, x: int, y: int) -> Cell:
        return self.grid[y][x]

    def _neighbors(self, c: Cell) -> List[Tuple[int, int, int]]:
        out = []
        for d in (N, E, S, W):
            nx, ny = c.x + DX[d], c.y + DY[d]
            if self._in_bounds(nx, ny) and not self.cell(nx, ny).visited:
                out.append((nx, ny, d))
        random.shuffle(out)
        return out

    def _generate(self):
        # Depth-first search / recursive backtracker: "perfect maze"
        stack = []
        start = self.cell(0, 0)
        start.visited = True
        stack.append(start)

        while stack:
            current = stack[-1]
            neigh = self._neighbors(current)
            if not neigh:
                stack.pop()
                continue
            nx, ny, d = neigh[0]
            nxt = self.cell(nx, ny)
            # carve passage
            current.walls[d] = False
            nxt.walls[OPP[d]] = False
            nxt.visited = True
            stack.append(nxt)

        # Clear visited flags for gameplay
        for row in self.grid:
            for c in row:
                c.visited = False

    def can_move(self, x: int, y: int, direction: int) -> bool:
        c = self.cell(x, y)
        if c.walls[direction]:
            return False
        nx, ny = x + DX[direction], y + DY[direction]
        return self._in_bounds(nx, ny)

    def move(self, x: int, y: int, direction: int) -> Tuple[int, int]:
        if self.can_move(x, y, direction):
            return x + DX[direction], y + DY[direction]
        return x, y
