# RetroPie Maze Port (pygame)

This package contains a small pygame maze game packaged as a RetroPie **Ports** entry.

## Install on RetroPie
1. Copy this folder to your RetroPie system (e.g. via SCP).
2. Run:

```bash
chmod +x install_to_retropie.sh
./install_to_retropie.sh
```

Or manually copy `maze/` to `/home/pi/RetroPie/roms/ports/maze/` and make `maze.sh` executable.

## Launch
- EmulationStation: **Ports** -> `maze.sh`
- Or from terminal:

```bash
export SDL_VIDEODRIVER=fbcon
export SDL_FBDEV=/dev/fb0
/home/pi/RetroPie/roms/ports/maze/maze.sh
```

If you get a black screen on newer KMS setups, try:

```bash
export SDL_VIDEODRIVER=kmsdrm
/home/pi/RetroPie/roms/ports/maze/maze.sh
```

## Controls
- Move: Arrow keys / WASD / D-pad
- New maze: R (or A/Start on many controllers)
- Quit: Esc / Q (or B/Select on many controllers)

## Notes about fonts
This game uses `pygame.freetype` when available to avoid issues when `pygame.font` is missing on some ARM builds.
