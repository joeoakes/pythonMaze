#!/usr/bin/env python3
"""
RetroPie Maze (pygame) - framebuffer friendly
- Fullscreen SDL (fbcon/kmsdrm friendly)
- Keyboard: arrows/WASD to move, R regenerate, Esc/Q quit
- Optional joystick/d-pad supported via pygame joystick events
- Text uses pygame.freetype when available (works even when pygame.font is missing)
"""
import os
import sys
import random
import time

# Helpful when running from EmulationStation / framebuffer
os.environ.setdefault("SDL_NOMOUSE", "1")

import pygame

# Prefer freetype; fallback to pygame.font if available; otherwise no text.
HAS_FREETYPE = False
HAS_FONT = False
try:
    import pygame.freetype as freetype
    HAS_FREETYPE = True
except Exception:
    HAS_FREETYPE = False

try:
    import pygame.font as pgfont
    HAS_FONT = True
except Exception:
    HAS_FONT = False


CELL = 24        # cell size in pixels (tune for Pi)
MAZE_W = 31      # odd sizes look nicer for perfect mazes
MAZE_H = 21
FPS = 60

# Colors
BG = (10, 10, 10)
WALL = (230, 230, 230)
PATH = (20, 20, 20)
PLAYER = (80, 180, 255)
GOAL = (80, 255, 120)
HUD = (240, 240, 240)

def clamp(v, lo, hi):
    return lo if v < lo else hi if v > hi else v

def generate_maze(w, h, rng):
    """
    Generate a perfect maze using recursive backtracker on a grid where walls are cells.
    Representation: 1 = wall, 0 = open.
    Uses odd dimensions; start at (1,1).
    """
    # Ensure odd
    if w % 2 == 0: w += 1
    if h % 2 == 0: h += 1

    grid = [[1 for _ in range(w)] for __ in range(h)]
    start = (1, 1)
    stack = [start]
    grid[start[1]][start[0]] = 0

    dirs = [(2,0), (-2,0), (0,2), (0,-2)]
    while stack:
        x, y = stack[-1]
        neighbors = []
        for dx, dy in dirs:
            nx, ny = x + dx, y + dy
            if 1 <= nx < w-1 and 1 <= ny < h-1 and grid[ny][nx] == 1:
                neighbors.append((nx, ny, dx, dy))
        if neighbors:
            nx, ny, dx, dy = rng.choice(neighbors)
            # carve passage
            grid[y + dy//2][x + dx//2] = 0
            grid[ny][nx] = 0
            stack.append((nx, ny))
        else:
            stack.pop()

    return grid

def find_farthest_open(grid, start):
    """BFS to find farthest open cell from start; returns cell coords."""
    from collections import deque
    h = len(grid); w = len(grid[0])
    sx, sy = start
    q = deque([(sx, sy)])
    dist = [[-1]*w for _ in range(h)]
    dist[sy][sx] = 0
    far = (sx, sy)
    while q:
        x, y = q.popleft()
        if dist[y][x] > dist[far[1]][far[0]]:
            far = (x, y)
        for dx, dy in [(1,0),(-1,0),(0,1),(0,-1)]:
            nx, ny = x+dx, y+dy
            if 0 <= nx < w and 0 <= ny < h and grid[ny][nx] == 0 and dist[ny][nx] == -1:
                dist[ny][nx] = dist[y][x] + 1
                q.append((nx, ny))
    return far, dist[far[1]][far[0]]

class TextRenderer:
    def __init__(self):
        self.mode = "none"
        self.small = None
        self.big = None
        if HAS_FREETYPE:
            self.mode = "freetype"
            self.small = freetype.SysFont(None, 18)
            self.big = freetype.SysFont(None, 28)
        elif HAS_FONT:
            self.mode = "font"
            pgfont.init()
            self.small = pgfont.SysFont(None, 18)
            self.big = pgfont.SysFont(None, 28)

    def draw(self, surf, text, pos, color=HUD, big=False):
        if self.mode == "freetype":
            (self.big if big else self.small).render_to(surf, pos, text, color)
        elif self.mode == "font":
            f = self.big if big else self.small
            img = f.render(text, True, color)
            surf.blit(img, pos)
        # else: no text

def init_joystick():
    pygame.joystick.init()
    if pygame.joystick.get_count() > 0:
        js = pygame.joystick.Joystick(0)
        js.init()
        return js
    return None

def main():
    rng = random.Random()
    pygame.init()

    # Framebuffer-friendly fullscreen
    flags = pygame.FULLSCREEN
    try:
        screen = pygame.display.set_mode((0,0), flags)
    except Exception:
        # fallback windowed
        screen = pygame.display.set_mode((800,600))

    pygame.display.set_caption("RetroPie Maze (pygame)")
    clock = pygame.time.Clock()

    text = TextRenderer()
    js = init_joystick()

    def new_game():
        nonlocal grid, player, goal, steps, started, start_time, best_time
        grid = generate_maze(MAZE_W, MAZE_H, rng)
        player = (1, 1)
        goal, _ = find_farthest_open(grid, player)
        steps = 0
        started = True
        start_time = time.time()
        # best_time persists per run
        return

    grid = []
    player = (1,1)
    goal = (MAZE_W-2, MAZE_H-2)
    steps = 0
    started = False
    start_time = 0.0
    best_time = None
    won = False

    new_game()

    # Compute drawing area and centering
    sw, sh = screen.get_size()
    maze_px_w = len(grid[0]) * CELL
    maze_px_h = len(grid) * CELL
    offset_x = max(0, (sw - maze_px_w)//2)
    offset_y = max(0, (sh - maze_px_h)//2)

    # Movement handling
    move_cooldown = 0.0
    MOVE_DELAY = 0.08  # seconds (d-pad friendly)

    def try_move(dx, dy):
        nonlocal player, steps, won, best_time
        x, y = player
        nx, ny = x+dx, y+dy
        if grid[ny][nx] == 0:
            player = (nx, ny)
            steps += 1
            if player == goal:
                won = True
                t = time.time() - start_time
                if best_time is None or t < best_time:
                    best_time = t

    running = True
    while running:
        dt = clock.tick(FPS) / 1000.0
        move_cooldown = max(0.0, move_cooldown - dt)

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False

            if event.type == pygame.KEYDOWN:
                if event.key in (pygame.K_ESCAPE, pygame.K_q):
                    running = False
                elif event.key == pygame.K_r:
                    won = False
                    new_game()
                elif move_cooldown <= 0.0:
                    if event.key in (pygame.K_LEFT, pygame.K_a):
                        try_move(-1, 0); move_cooldown = MOVE_DELAY
                    elif event.key in (pygame.K_RIGHT, pygame.K_d):
                        try_move(1, 0); move_cooldown = MOVE_DELAY
                    elif event.key in (pygame.K_UP, pygame.K_w):
                        try_move(0, -1); move_cooldown = MOVE_DELAY
                    elif event.key in (pygame.K_DOWN, pygame.K_s):
                        try_move(0, 1); move_cooldown = MOVE_DELAY

            # Basic joystick/d-pad support
            if event.type == pygame.JOYHATMOTION and move_cooldown <= 0.0:
                hx, hy = event.value
                if hx == -1: try_move(-1, 0); move_cooldown = MOVE_DELAY
                elif hx == 1: try_move(1, 0); move_cooldown = MOVE_DELAY
                elif hy == 1: try_move(0, -1); move_cooldown = MOVE_DELAY
                elif hy == -1: try_move(0, 1); move_cooldown = MOVE_DELAY

            if event.type == pygame.JOYBUTTONDOWN:
                # Common mappings: 0=A, 1=B, 6=Select, 7=Start (varies)
                if event.button in (1, 6):  # B/Select
                    running = False
                elif event.button in (0, 7):  # A/Start
                    if won:
                        won = False
                    new_game()

        # Recompute offsets if resolution changes
        sw, sh = screen.get_size()
        offset_x = max(0, (sw - maze_px_w)//2)
        offset_y = max(0, (sh - maze_px_h)//2)

        # Draw
        screen.fill(BG)

        # Maze cells
        for y in range(len(grid)):
            for x in range(len(grid[0])):
                r = pygame.Rect(offset_x + x*CELL, offset_y + y*CELL, CELL, CELL)
                if grid[y][x] == 1:
                    pygame.draw.rect(screen, WALL, r)
                else:
                    pygame.draw.rect(screen, PATH, r)

        # Goal
        gx, gy = goal
        gr = pygame.Rect(offset_x + gx*CELL, offset_y + gy*CELL, CELL, CELL)
        pygame.draw.rect(screen, GOAL, gr)

        # Player
        px, py = player
        pr = pygame.Rect(offset_x + px*CELL, offset_y + py*CELL, CELL, CELL)
        pygame.draw.rect(screen, PLAYER, pr)

        # HUD
        elapsed = time.time() - start_time
        hud_y = 10
        hud_x = 10
        text.draw(screen, "RetroPie Maze", (hud_x, hud_y), HUD, big=True)
        hud_y += 30
        text.draw(screen, "Move: Arrows/WASD or D-Pad  |  R: new  |  Esc/Q: quit", (hud_x, hud_y), HUD)
        hud_y += 22
        text.draw(screen, f"Steps: {steps}   Time: {elapsed:0.1f}s" + (f"   Best: {best_time:0.1f}s" if best_time else ""), (hud_x, hud_y), HUD)

        if won:
            msg = "YOU WIN!  Press A/Start or R for new maze"
            # center message
            if HAS_FREETYPE:
                rect = text.big.get_rect(msg)
                text.draw(screen, msg, ((sw-rect.width)//2, sh-80), GOAL, big=True)
            else:
                text.draw(screen, msg, (sw//6, sh-80), GOAL, big=True)

        pygame.display.flip()

    pygame.quit()
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
