#!/bin/bash
# RetroPie Ports launcher for Maze (pygame)
# Place this folder in: /home/pi/RetroPie/roms/ports/maze
# Launch from EmulationStation: Ports -> maze.sh

# Framebuffer drivers:
#  - fbcon (older RetroPie images)
#  - kmsdrm (newer Raspberry Pi OS / KMS)
# Try fbcon first; if blank screen, switch to kmsdrm.

export SDL_VIDEODRIVER=${SDL_VIDEODRIVER:-fbcon}
export SDL_FBDEV=${SDL_FBDEV:-/dev/fb0}
export SDL_NOMOUSE=1

# Hide mouse cursor if it appears
export SDL_MOUSE_RELATIVE=0

cd "$(dirname "$0")"

# Optional: ensure python uses user site packages (pip --user)
export PYTHONNOUSERSITE=0

python3 main.py
