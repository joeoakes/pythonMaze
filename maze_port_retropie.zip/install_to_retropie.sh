#!/bin/bash
set -e

SRC_DIR="$(cd "$(dirname "$0")" && pwd)"
DEST_DIR="/home/pi/RetroPie/roms/ports/maze"

echo "[+] Installing Maze port to: $DEST_DIR"
mkdir -p "$DEST_DIR"
cp -r "$SRC_DIR/maze/"* "$DEST_DIR/"

chmod +x "$DEST_DIR/maze.sh"

echo "[+] Done."
echo "    - Restart EmulationStation or reboot."
echo "    - Find it under: Ports -> maze.sh"
